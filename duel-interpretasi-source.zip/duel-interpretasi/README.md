# Duel Interpretasi — Prototipe

Prototipe game 3D first-person mobile dengan latar pedesaan fantasi. Fokus tes pertama adalah membaca perilaku musuh, menguji dugaan, lalu menyusun interpretasi psikologis.

## Menjalankan lokal

```bash
npm install
npm run dev
```

## Kontrol

### Desktop
- WASD: bergerak
- Mouse: melihat
- E: amati
- F: uji respons
- Space: menghindar
- R: interpretasi

### Mobile
- Joystick kiri: bergerak
- Geser sisi kanan: melihat
- Tombol AMATI, UJI, HINDAR, dan INTERPRETASI

## Build dan GitHub Pages

```bash
npm run build
```

Workflow `.github/workflows/deploy.yml` sudah disertakan. Aktifkan **Settings → Pages → Source: GitHub Actions** pada repository GitHub.

## Scope prototipe

- Satu area desa prosedural bergaya cel-shaded
- Satu encounter Roh Orang-orangan Sawah
- Tiga petunjuk perilaku
- Dua tindakan pengujian
- Musuh yang mempelajari pola menghindar pemain
- Tiga interpretasi dan tiga resolusi
- Penyimpanan checkpoint melalui localStorage
